package main

import (
	//"fmt"
	//"log"
	//"os/exec"

	//"strings"
	"testing"
	//"bytes"
	//"io"
	//"os"
)

func TestEsistenzaFunzioni(t *testing.T) {
	estraiCarta()
	dai4Carte()
	mazzoPoker()
	carta(4)
}
